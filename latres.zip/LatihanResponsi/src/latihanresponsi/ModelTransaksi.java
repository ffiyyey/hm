package LatihanResponsi;

import javax.swing.JOptionPane;

public class ModelTransaksi {

    private String namaPelanggan;
    private String namaObat;
    private int hargaSatuan;
    private int jumlahBeli;
    private ListenerTransaksi listener;

    public void setListener(ListenerTransaksi listener) {
        this.listener = listener;
    }

    protected void fireOnChange() {
        if (listener != null) {
            listener.onChange(this);
        }
    }

    public String getNamaPelanggan() {
        return namaPelanggan;
    }

    public void setNamaPelanggan(String namaPelanggan) {
        this.namaPelanggan = namaPelanggan;
        fireOnChange();
    }

    public String getNamaObat() {
        return namaObat;
    }

    public void setNamaObat(String namaObat) {
        this.namaObat = namaObat;
        fireOnChange();
    }

    public int getHargaSatuan() {
        return hargaSatuan;
    }

    public void setHargaSatuan(int hargaSatuan) {
        this.hargaSatuan = hargaSatuan;
        fireOnChange();
    }

    public int getJumlahBeli() {
        return jumlahBeli;
    }

    public void setJumlahBeli(int jumlahBeli) {
        this.jumlahBeli = jumlahBeli;
        fireOnChange();
    }

    public void resetForm() {
        setNamaPelanggan("");
        setNamaObat("");
        setHargaSatuan(0);
        setJumlahBeli(0);
    }

    public void submitForm(ViewTransaksi view) {
        int total = hargaSatuan * jumlahBeli;
        if (jumlahBeli > 5) {
            total -= (total * 10 / 100);
        }

        JOptionPane.showMessageDialog(null,
            "Transaksi berhasil!\n" +
            "Nama: " + namaPelanggan + "\n" +
            "Obat: " + namaObat + "\n" +
            "Total Bayar: Rp " + total);
    }
}
