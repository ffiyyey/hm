package LatihanResponsi;

import javax.swing.JOptionPane;

public class ControllerTransaksi {

    private ModelTransaksi model;

    public void setModel(ModelTransaksi model) {
        this.model = model;
    }

    public void resetForm(ViewTransaksi view) {
        if (view.getFnamaPelanggan().getText().isEmpty() &&
            view.getFnamaObat().getText().isEmpty() &&
            view.getFhargaSatuan().getText().isEmpty() &&
            view.getFjumlahBeli().getText().isEmpty()) {
            return;
        }
        model.resetForm();
    }

    public void submitForm(ViewTransaksi view) {
        String nama = view.getFnamaPelanggan().getText().trim();
        String obat = view.getFnamaObat().getText().trim();
        String harga = view.getFhargaSatuan().getText().trim();
        String jumlah = view.getFjumlahBeli().getText().trim();

        if (nama.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Nama pelanggan belum diisi!");
        } else if (obat.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Nama obat belum diisi!");
        } else if (harga.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Harga satuan belum diisi!");
        } else if (jumlah.isEmpty()) {
            JOptionPane.showMessageDialog(view, "Jumlah beli belum diisi!");
        } else {
            try {
                int hrg = Integer.parseInt(harga);
                int jml = Integer.parseInt(jumlah);

                model.setNamaPelanggan(nama);
                model.setNamaObat(obat);
                model.setHargaSatuan(hrg);
                model.setJumlahBeli(jml);

                model.submitForm(view);
                model.resetForm();

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(view, "Harga dan jumlah harus berupa angka!");
            }
        }
    }
}

