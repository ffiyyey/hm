package LatihanResponsi;

import javax.swing.*;
import java.awt.event.*;

public class ViewTransaksi extends JFrame implements ActionListener, ListenerTransaksi {

    final JTextField fnamaPelanggan = new JTextField(10);
    final JTextField fnamaObat = new JTextField(10);
    final JTextField fhargaSatuan = new JTextField(10);
    final JTextField fjumlahBeli = new JTextField(10);

    JLabel lnamaPelanggan = new JLabel("Nama Pelanggan");
    JLabel lnamaObat = new JLabel("Nama Obat");
    JLabel lhargaSatuan = new JLabel("Harga Satuan");
    JLabel ljumlahBeli = new JLabel("Jumlah Beli");

    JButton btnSave = new JButton("Save");
    JButton btnReset = new JButton("Reset");

    ControllerTransaksi controller;
    ModelTransaksi model;

    public ViewTransaksi() {
        setTitle("Latihan Responsi - Apotek");
        setSize(350, 230);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        add(lnamaPelanggan); add(fnamaPelanggan);
        add(lnamaObat); add(fnamaObat);
        add(lhargaSatuan); add(fhargaSatuan);
        add(ljumlahBeli); add(fjumlahBeli);
        add(btnSave); add(btnReset);

        lnamaPelanggan.setBounds(10, 10, 120, 20);
        fnamaPelanggan.setBounds(130, 10, 170, 20);
        lnamaObat.setBounds(10, 40, 120, 20);
        fnamaObat.setBounds(130, 40, 170, 20);
        lhargaSatuan.setBounds(10, 70, 120, 20);
        fhargaSatuan.setBounds(130, 70, 170, 20);
        ljumlahBeli.setBounds(10, 100, 120, 20);
        fjumlahBeli.setBounds(130, 100, 170, 20);
        btnReset.setBounds(130, 140, 80, 20);
        btnSave.setBounds(220, 140, 80, 20);

        btnSave.addActionListener(this);
        btnReset.addActionListener(this);

        controller = new ControllerTransaksi();
        model = new ModelTransaksi();
        model.setListener(this);
        controller.setModel(model);

        setVisible(true);
    }

    public JTextField getFnamaPelanggan() {
        return fnamaPelanggan;
    }

    public JTextField getFnamaObat() {
        return fnamaObat;
    }

    public JTextField getFhargaSatuan() {
        return fhargaSatuan;
    }

    public JTextField getFjumlahBeli() {
        return fjumlahBeli;
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnSave) {
            controller.submitForm(this);
        } else if (e.getSource() == btnReset) {
            controller.resetForm(this);
        }
    }

    public void onChange(ModelTransaksi model) {
        fnamaPelanggan.setText(model.getNamaPelanggan());
        fnamaObat.setText(model.getNamaObat());
        fhargaSatuan.setText(String.valueOf(model.getHargaSatuan()));
        fjumlahBeli.setText(String.valueOf(model.getJumlahBeli()));
    }
}

