package LatihanResponsi;

public interface ListenerTransaksi {
    public void onChange(ModelTransaksi model);
}

